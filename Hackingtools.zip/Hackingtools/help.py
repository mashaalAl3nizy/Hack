المكاتب 👇🏼 :
secrets / uuid / requests / time



url = 'https://www.instagram.com/accounts/login/ajax/'



headers = {
'cookie': 'ig_did=303991DA-0420-41AC-A26D-D9F27C8DF624; mid=X0padwAEAAEPS5xI4RZu1YV6z7zS; rur=ASH; csrftoken=xX0K5q7XikrU1LAnenqEVKqb7J3qK4S6; urlgen="{\"185.88.26.35\": 201031}:1kC1CG:D41DVXmf-j-T5nYho3c7g7K3MQU"',
'user-agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36',
'x-csrftoken': 'xX0K5q7XikrU1LAnenqEVKqb7J3qK4S6',
'x-ig-app-id': '936619743392459',
'x-ig-www-claim': 'hmac.AR3tv9HzzLkZIUlGMRu3lzHfEeePw9CgWg8cuXGO22LfU8x0',
'x-instagram-ajax': '0c15f4d7d44a',
'x-requested-with': 'XMLHttpRequest'
}


data = {
'username': f'{user}',
'enc_password': f'#PWD_INSTAGRAM_BROWSER:0:&:{pess}',
'queryParams': '{}',
'optIntoOneTap': 'false'}


url_id 👇🏼 :
https://www.instagram.com/joker/?__a=1



url_spam 👇🏼:
https://www.instagram.com/users/25025320/report/



data spam 👇🏼: 
data_spam = {
	'source_name': '',
	'reason_id': 1,
	'frx_context': ''	}
		
